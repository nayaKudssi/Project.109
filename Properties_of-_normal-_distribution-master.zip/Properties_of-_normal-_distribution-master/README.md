# Properties_of-_normal-_distribution
project solution for c109
